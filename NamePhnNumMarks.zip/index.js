let student = {
  name: "Ananya Biswal",
  phonenumber: "6371858557",
  marks: "71.9",
  };
console.log(student.name); // "Ananya Biswal"
console.log(student.phonenumber); // "6371858557"
console.log(student["marks"]); // 71.9