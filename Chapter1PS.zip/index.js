//Q1
let a = "Annie"
let b = 25
console.log(a+b)

//Q2
console.log(typeof (a+b))

//Q3
const a1 = {
  name: "Annie",
  section: 1,
  isPrincipal: true
  }
  //a1 = 25
a1['friend'] = "Abhishek"
a1['name'] = "Ananya"
console.log(a1)

//Q4
const dict = {
  appreciate: "recognize the full worth of",
  yakka:"espcially hard work",
  atarxia: "a state of freedom from emtional distrubance and anxiety",
  empath: "meaning and examples",
}
console.log(dict.yakka)
console.log(dict.empath)